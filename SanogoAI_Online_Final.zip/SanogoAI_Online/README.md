# Sanogo AI — backend en ligne

1. Déploie le dossier sur un hébergeur Node.js (le `render.yaml` est inclus pour Render).
2. Ajoute `ANTHROPIC_API_KEY` dans les variables secrètes du serveur.
3. Ajoute `CLAUDE_MODEL=claude-sonnet-5`.
4. Récupère l'URL HTTPS du backend.
5. Dans `config.js`, remplace l'URL `REMPLACE-MOI...` par cette URL.
6. Ouvre ensuite `index.html` dans SPCK.

Test : ouvre `https://TON-BACKEND/health` et vérifie que le serveur répond avec un statut `ok`.

Ne mets jamais la clé Anthropic dans `config.js`, `script.js` ou l'APK.

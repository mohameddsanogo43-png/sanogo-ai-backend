// Remplace par l'URL HTTPS de ton backend déployé.
const API_BASE_URL = "https://REMPLACE-MOI-PAR-TON-BACKEND.onrender.com";
